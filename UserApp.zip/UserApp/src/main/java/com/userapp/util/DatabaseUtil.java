package com.userapp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DatabaseUtil {
	
    private static Connection connection;
    private static PreparedStatement statement;
    private static ResultSet resultset;
    
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/UserTest";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "pass123";



    public static Connection openConnection() throws SQLException {
        Connection connection = null;
        try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public static void startTransaction(Connection connection) throws SQLException {
            connection.setAutoCommit(false);
    }


	public static void commitTransaction(Connection connection) throws SQLException {
	        connection.commit();
	}

    public static void rollbackTransaction(Connection connection) throws SQLException {
	        connection.rollback();    	
    }
    

    public static ResultSet executeQuery(String sql, Object... params) throws SQLException{
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {
            connection = openConnection();
            if (params.length == 1) {
            	statement = connection.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            	statement.setLong(1, (long) params[0]);
            	resultSet = statement.executeQuery();
			}
            else {
                statement = connection.prepareStatement(sql);
                resultSet = statement.executeQuery();
			}
            return resultSet;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } 
    }
    
    public static int executeUpdate(String sql, String... params) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        int affectedRows = 0;
        try {
            connection = openConnection();
            statement = connection.prepareStatement(sql);            
            statement.setString(1, params[0]);
            statement.setString(2, params[1]);
            statement.setLong(3, Long.parseLong(params[2]));
            affectedRows = statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
        	closeDB();
        }
        return affectedRows;
    }

    public static int executeInsert(String sql, String... params) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        int affectedRows = 0;
        try {
            connection = openConnection();
            statement = connection.prepareStatement(sql);            
            statement.setString(1, params[0]);
            statement.setString(2, params[1]);            
            affectedRows = statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
        	closeDB();
        }
        return affectedRows;
    }
    
    public static int executeDelete(String sql, String... params) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        int affectedRows = 0;
        connection = openConnection();
        statement = connection.prepareStatement(sql);
        statement.setLong(1, Long.parseLong(params[0]));
        affectedRows = statement.executeUpdate();        
		return affectedRows;
    }

	public static void closeDB() throws SQLException {
		if (resultset != null) {
			resultset.close();	
		}		
		if (statement != null) {
			statement.close();	
		}		
		if (statement != null) {
			statement.close();
		}		
		if (connection != null) {
			connection.close();
		}
	}

    // Egyéb segédfüggvények, adatbázis-műveletek stb.
}