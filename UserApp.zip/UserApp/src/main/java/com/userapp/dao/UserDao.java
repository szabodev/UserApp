package com.userapp.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.userapp.entity.User;
import com.userapp.util.DatabaseUtil;


public class UserDao {

	private static final String INSERT_USER = "INSERT INTO public.\"Users\" (\"Name\", \"Email\") VALUES (?, ?);";	
	private static final String SELECT_ALL_USERS = "SELECT * FROM public.\"Users\"";
	private static final String SELECT_USER_BY_ID = "SELECT * FROM public.\"Users\" WHERE \"Id\" = ?";
	private static final String UPDATE_USER = "UPDATE public.\"Users\" SET  \"Name\" = ?, \"Email\" = ? WHERE \"Id\" =  ?";
	private static final String DELETE_USER = "DELETE FROM public.\"Users\" WHERE \"Id\" = ?";
    

    public UserDao() {
    }
    
        
    public int createUser(User user) {
        int success = 0;
        Connection connection;
        try {
            connection = DatabaseUtil.openConnection();
            DatabaseUtil.startTransaction(connection);     
            String id = user.getId().toString();
            success = DatabaseUtil.executeInsert(INSERT_USER,user.getName(), user.getEmail());
            DatabaseUtil.commitTransaction(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return success;
    }
    
    
	public boolean updateUser(String... params) {
    	boolean success = false; 
    	
    	try {
			DatabaseUtil.executeUpdate(UPDATE_USER, params[1], params[2], params[0]);
			success = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	return success;
    }

	
    public boolean deleteUser(String userId) {
    	boolean success = false;   
    			
    	try {
    		DatabaseUtil.executeDelete(DELETE_USER, userId);
			success = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	return success;
    }
    
    
    public List<User> getAllUsers() {
    	List<User> users = new ArrayList<User>();
    	try {
    		ResultSet resultSet = DatabaseUtil.executeQuery(SELECT_ALL_USERS);    		
            while (resultSet.next()) {
            	long userId = resultSet.getLong("id");
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                User user = new User(userId, name, email);
                users.add(user);
            }
            DatabaseUtil.closeDB();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return users;
    }

    public User getUserById(long userId) {
    	User user = null;
    	try {
    		ResultSet resultSet = DatabaseUtil.executeQuery(SELECT_USER_BY_ID, userId);
    		if (resultSet.first()) {
    		    String name = resultSet.getString("name");
    		    String email = resultSet.getString("email");
    		    user = new User(userId, name, email);
    		}
		} catch (SQLException e) {
			e.printStackTrace();
		}    	
		return user;
    }
}