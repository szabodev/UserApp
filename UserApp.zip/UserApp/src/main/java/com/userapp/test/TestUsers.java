package com.userapp.test;

import com.userapp.dao.UserDao;
import com.userapp.entity.User;

public class TestUsers {

	public static void main(String[] args) {
//		UserDao userDao = new UserDao();
//		User user = new User();
//		user.setName("testXXX123ncnc");
//		user.setEmail("testXXX789mnmn@test765KH@com");
//		userDao.deleteUser(14);
//		userDao.updateUser("16", "BUBUUserName234525", "gh8778JHEmail2@Users.com");
//		userDao.createUser(user);
		
//		userDao.getAllUsers();

	}

}
