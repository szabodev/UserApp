package com.userapp.service;

import java.util.List;

import com.userapp.entity.User;
import com.userapp.dao.UserDao;

public class UserService {
    private UserDao userDao;
    
    public UserService() {
        userDao = new UserDao();
    }
    
    public List<User> getAllUsers() {
        return userDao.getAllUsers();
    }
    
    public User getUserById(int id) {
        return userDao.getUserById(id);
    }
    
    public void createUser(User user) {
			userDao.createUser(user);
}
}
